Imports System.Collections.Generic
Imports System.Configuration
Imports System.Data
Imports System.Linq
Imports System.Windows

''' <summary>
''' Interaction logic for App.xaml
''' </summary>
Public Partial Class App
	Inherits Application
End Class
