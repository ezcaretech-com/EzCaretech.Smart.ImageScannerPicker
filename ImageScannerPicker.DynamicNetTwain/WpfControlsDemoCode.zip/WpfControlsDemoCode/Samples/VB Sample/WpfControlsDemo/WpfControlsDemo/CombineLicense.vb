﻿Imports System
Imports System.Collections.Generic
Imports System.IO
Imports System.Runtime.InteropServices
Imports System.Text


Public Class LicenseLoader
    <DllImport("kernel32.dll")> _
    Private Shared Function GetSystemDirectory(<Out> lpBuffer As StringBuilder, uSize As UInteger) As UInteger
    End Function

    <DllImport("kernel32.dll")> _
    Private Shared Function GetWindowsDirectory(<Out> lpBuffer As StringBuilder, uSize As UInteger) As UInteger
    End Function

    Private Shared Function GetLicenseFilePath() As String
        Dim sbsSystemDir As New StringBuilder(256)
        Dim iLength As UInteger = 0
        iLength = GetSystemDirectory(sbsSystemDir, 256)
        If iLength = 0 Then
            Return Nothing
        End If
        Dim sbsWindowsDir As New StringBuilder(256)
        iLength = GetWindowsDirectory(sbsWindowsDir, 256)

        If iLength = 0 Then
            Return Nothing
        End If
        If sbsWindowsDir.Length > 0 Then
            If IntPtr.Size = 8 Then
                sbsWindowsDir.Append("\SysWOW64\DynamsoftDotNetTwain.lic")
            Else
                sbsWindowsDir.Append("\System32\DynamsoftDotNetTwain.lic")

            End If
        End If
        Return sbsWindowsDir.ToString()
    End Function

    Private Shared Function ReadSystemLocalLicense(strlicensePath As String) As List(Of String)
        Dim liststringTempListLicense As List(Of String) = Nothing
        Try
            If File.Exists(strlicensePath) Then
                Dim stringarrTempAllLines As String() = File.ReadAllLines(strlicensePath)
                For Each strTemp As String In stringarrTempAllLines
                    Dim iTempIndex As Integer = strTemp.IndexOf("SerialNo")
                    If iTempIndex <> -1 Then
                        Dim iIndex1 As Integer = strTemp.IndexOf("=")
                        If iIndex1 <> -1 Then
                            If liststringTempListLicense Is Nothing Then
                                liststringTempListLicense = New List(Of String)()
                            End If
                            Dim strTempLicense As String = strTemp.Substring((iIndex1 + 1), (strTemp.Length - (iIndex1 + 1)))
                            liststringTempListLicense.Add(strTempLicense)
                        End If
                    End If
                Next
            End If
        Catch
        End Try
        Return liststringTempListLicense
    End Function





    Private Shared Function GetCurrentPath() As String
        Dim strCurrentPath As String = System.IO.Directory.GetCurrentDirectory()
        Dim strCurrentPathtxt As String = strCurrentPath & "\lic.txt"
        Return strCurrentPathtxt
    End Function
    Private Shared Function ReadLicense(strPath As String) As String
        Try
            Dim strLicenseMessage As String = System.IO.File.ReadAllText(strPath)
            Dim beginIndex As Integer = strLicenseMessage.IndexOf("=""")
            Dim endIndex As Integer = strLicenseMessage.IndexOf(""";")
            Dim strLicense As String = Nothing
            If beginIndex <> -1 AndAlso endIndex <> -1 Then
                strLicense = strLicenseMessage.Substring(beginIndex + 2, endIndex - beginIndex - 2)
            End If
            Return strLicense
        Catch generatedExceptionName As Exception
            Dim strLicense As String = Nothing
            Return strLicense
        End Try
    End Function

    Private Shared Function CombineAllLicense(strCurrentPathLicense As String) As String
        If strCurrentPathLicense IsNot Nothing Then
            Try
                Dim strTempLicenseFilePath As String = GetLicenseFilePath()
                Dim tempListLicense As List(Of String) = ReadSystemLocalLicense(strTempLicenseFilePath)


                Dim objProductKeys As New StringBuilder()

                For Each temp As String In tempListLicense
                    If temp IsNot Nothing Then
                        objProductKeys.Append(temp)
                        objProductKeys.Append(";")
                    End If
                Next

                Dim strTempProductKey As String = objProductKeys.ToString()
                strTempProductKey = strTempProductKey & strCurrentPathLicense & ";"
                Return strTempProductKey
            Catch generatedExceptionName As Exception
                Dim strTempProductKey As String = strCurrentPathLicense & ";"
                Return strTempProductKey
            End Try
        Else
            Try
                Dim steTempLicenseFilePath As String = GetLicenseFilePath()
                Dim liststringTempListLicense As List(Of String) = ReadSystemLocalLicense(steTempLicenseFilePath)


                Dim objProductKeys As New StringBuilder()

                For Each temp As String In liststringTempListLicense
                    If temp IsNot Nothing Then
                        objProductKeys.Append(temp)
                        objProductKeys.Append(";")
                    End If
                Next

                Dim strTempProductKey As String = objProductKeys.ToString()
                Return strTempProductKey
            Catch generatedExceptionName As Exception
                Return Nothing
            End Try
        End If

    End Function

    Public Shared Function ReadLocalLicense() As String
        Dim strGetCurrentPath As String = LicenseLoader.GetCurrentPath()
        Dim strReadLicense As String = LicenseLoader.ReadLicense(strGetCurrentPath)
        Dim strCombineAllLicense As String = LicenseLoader.CombineAllLicense(strReadLicense)
        Return strCombineAllLicense
    End Function



End Class


